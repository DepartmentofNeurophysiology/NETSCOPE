restoredefaultpath;
clear RESTOREDEFAULTPATH_EXECUTED;

addpath(genpath('Toolbox'));